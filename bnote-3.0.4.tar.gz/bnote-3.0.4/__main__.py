from bnote.run import main

main(False)
