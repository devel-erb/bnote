Put in this folder your new python package (.whl files).

For translate :
translate-3.6.1-py2.py3-none-any.whl
libretranslatepy-2.1.1-py3-none-any.whl
click-8.1.7-py3-none-any.whl
lxml-5.2.2-cp311-cp311-linux_armv7l.whl
requests-2.32.3-py3-none-any.whl
certifi-2024.6.2-py3-none-any.whl
charset_normalizer-3.3.2-py3-none-any.whl
idna-3.7-py3-none-any.whl
urllib3-2.2.1-py3-none-any.whl
