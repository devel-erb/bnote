from bnote.run import main

main(True)
