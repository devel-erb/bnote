"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
from .l1l111ll1_opy_ import *
l1ll1lll1ll_opy_ = {l1l111l111l_opy_.l11111111ll_opy_.c: 0, l1l111l111l_opy_.l11111111ll_opy_.d: 2, l1l111l111l_opy_.l11111111ll_opy_.e: 4, l1l111l111l_opy_.l11111111ll_opy_.f: 5, l1l111l111l_opy_.l11111111ll_opy_.g: 7, l1l111l111l_opy_.l11111111ll_opy_.a: 9, l1l111l111l_opy_.l11111111ll_opy_.b: 11, "no": 0}
l1ll1l1l1ll_opy_ = {l1l111l111l_opy_.l1llllllll11_opy_.l1111111l11_opy_: -2, l1l111l111l_opy_.l1llllllll11_opy_.l1lllllll1ll_opy_: -1, l1l111l111l_opy_.l1llllllll11_opy_.l111111111l_opy_: -1, l1l111l111l_opy_.l1llllllll11_opy_.l1lllllll1l1_opy_: -1, l1l111l111l_opy_.l1llllllll11_opy_.l1llllllllll_opy_: 0, l1l111l111l_opy_.l1llllllll11_opy_.l11111111l1_opy_: 1, l1l111l111l_opy_.l1llllllll11_opy_.l1lllllllll1_opy_: 1, l1l111l111l_opy_.l1llllllll11_opy_.l1111111111_opy_: 1, l1l111l111l_opy_.l1llllllll11_opy_.l1llllllll1l_opy_: 2, "no": 0}
l1ll1ll1l1l_opy_ = {"p" :87, "pp": 82, "ppp": 77, "pppp": 72, "ppppp": 67, "pppppp": 62, "f": 102, "ff": 107, "fff": 112, "ffff": 117, "fffff": 122, "ffffff": 127, "mp": 92, "mf": 97, "sf": 100, "sfp": 100, "sfpp": 100, "fp": 100, "rf": 100, "rfz": 100, "sfz": 100, "sffz": 100, "fz": 100, "n": 100, "pf": 100, "sfzp": 100, "other-dynamics": 100}